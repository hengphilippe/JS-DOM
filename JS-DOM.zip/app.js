// getElementById
// #page-banner

// getElementsByClassName()
// console.log(document.getElementsByClassName("title"));

// getElementsByTagName()
// console.log(document.getElementsByTagName("span"));

// querySelector
// console.log(document.querySelectorAll("span"));

//querySelectorAll
// console.log(document.querySelectorAll("#book-list"));

// console.log(document.querySelector("h2"));
// let subTitle = document.querySelector("h2");
// subTitle.textContent="<p>From Sub P</p>";


// let header = document.querySelector(".title");
// let parent = header.parentElement;
// console.log(parent);

// books = document.querySelector("#book-list");
// let childs = books.children;
// console.log(childs);

// let books = document.querySelector("#book-list");
// console.log(books.nextElementSibling);

// let title = document.querySelector('.title');
// title.addEventListener('click', function(e) {
// 	// alert("Click on title");
// 	// console.log(e);
// });


// function simpleAction() {
// 	alert ("Click On title");
// }





